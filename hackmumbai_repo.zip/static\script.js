document.addEventListener('DOMContentLoaded', () => {
    // Theme Toggle Logic
    const themeToggle = document.getElementById('theme-toggle');
    const htmlElement = document.documentElement;
    
    if(localStorage.getItem('theme') === 'light') {
        htmlElement.setAttribute('data-theme', 'light');
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }

    themeToggle.addEventListener('click', () => {
        if(htmlElement.getAttribute('data-theme') === 'dark') {
            htmlElement.setAttribute('data-theme', 'light');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            localStorage.setItem('theme', 'light');
        } else {
            htmlElement.setAttribute('data-theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            localStorage.setItem('theme', 'dark');
        }
    });

    const form = document.getElementById('upload-form');
    const fileInput = document.getElementById('csv-file');
    const dropZone = document.getElementById('drop-zone');
    const fileNameDisplay = document.getElementById('file-name');
    const validationMsg = document.getElementById('validation-msg');
    const analyzeBtn = document.getElementById('analyze-btn');
    const uploadSection = document.getElementById('upload-section');
    const loadingSection = document.getElementById('loading-section');
    const resultsSection = document.getElementById('results-section');
    const progressBar = document.getElementById('progress-bar');
    const statusTip = document.getElementById('status-tip');
    const resetBtn = document.getElementById('reset-btn');
    const exportPdfBtn = document.getElementById('export-pdf-btn');
    const demoSelectorPanel = document.getElementById('demo-selector');

    let gaugeChartInstance = null;
    let impactChartInstance = null;
    let selectedFiles = null;

    // --- Drag & Drop & Browse Initialization ---
    
    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    ['dragreturn', 'dragenter', 'dragover', 'dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, (e) => { e.preventDefault(); e.stopPropagation(); }, false);
    });

    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, () => {
            dropZone.classList.add('dragover');
            dropZone.style.boxShadow = "0 0 20px rgba(59, 130, 246, 0.5)";
            dropZone.style.borderColor = "#3b82f6";
        }, false);
    });

    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, () => {
            dropZone.classList.remove('dragover');
            dropZone.style.boxShadow = "none";
            dropZone.style.borderColor = "var(--glass-border)";
        }, false);
    });

    dropZone.addEventListener('drop', (e) => {
        handleFiles(e.dataTransfer.files);
    });

    function handleFiles(files) {
        if(files.length > 0) {
            const dt = new DataTransfer();
            for(let i=0; i<files.length; i++) {
                if(files[i].name.toLowerCase().endsWith('.csv')) {
                    dt.items.add(files[i]);
                }
            }
            
            if(dt.files.length > 0) {
                selectedFiles = dt.files;
                fileInput.files = dt.files;
                
                if(dt.files.length === 1) {
                    fileNameDisplay.innerHTML = `<i class="fas fa-file-csv"></i> ${dt.files[0].name}`;
                } else {
                    fileNameDisplay.innerHTML = `<i class="fas fa-copy"></i> ${dt.files.length} Profiles Ready`;
                }
                
                validationMsg.textContent = '';
                analyzeBtn.disabled = false;
                
                // Auto trigger submit for continuous UX flow
                form.dispatchEvent(new Event('submit'));
                
            } else {
                selectedFiles = null;
                fileNameDisplay.textContent = '';
                validationMsg.innerHTML = '<i class="fas fa-times-circle"></i> Invalid file. Please upload a pure .CSV file.';
                analyzeBtn.disabled = true;
                alert("Invalid format. Please use CSV only.");
            }
        }
    }

    // --- Demo Selector ---
    const demoBtns = document.querySelectorAll('.btn-demo');
    demoBtns.forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const fileName = btn.getAttribute('data-file');
            
            try {
                const response = await fetch('/static/' + fileName);
                const blob = await response.blob();
                const file = new File([blob], fileName, { type: 'text/csv' });
                
                const dt = new DataTransfer();
                dt.items.add(file);
                fileInput.files = dt.files;
                handleFiles(dt.files);
                
            } catch(e) {
                console.error("Failed to load demo file", e);
            }
        });
    });

    // --- Submission & Analysis ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if(!selectedFiles || selectedFiles.length === 0) return;

        uploadSection.classList.add('hidden');
        demoSelectorPanel.classList.add('hidden');
        loadingSection.classList.remove('hidden');
        
        const isBatch = selectedFiles.length > 1;
        const tips = isBatch ? [
            "Parsing Multi-CSV structure...",
            "Scaling AI to batch processing mode...",
            "Parallelizing Gradient Boosting trees...",
            "Calculating comprehensive Trust distributions..."
        ] : [
            "Parsing CSV transaction rows...",
            "Extracting entity footprints...",
            "Running feature engineering...",
            "Scoring via ML Ensemble...",
            "Calculating SHAP vectors...",
            "Finalizing TrustScore..."
        ];
        
        let progress = 0;
        let tipIdx = 0;
        
        const loaderInterval = setInterval(() => {
            progress += Math.random() * 12;
            if (progress >= 95) progress = 95;
            progressBar.style.width = `${progress}%`;
            
            if(Math.random() > 0.4 && tipIdx < tips.length - 1) {
                tipIdx++;
                statusTip.textContent = tips[tipIdx];
            }
        }, 120);

        try {
            const formData = new FormData();
            for(let i=0; i<selectedFiles.length; i++) {
                formData.append('files', selectedFiles[i]);
            }

            // Calls backend /score endpoint
            const res = await fetch('/score', {
                method: 'POST',
                body: formData
            });
            const data = await res.json();

            clearInterval(loaderInterval);
            progressBar.style.width = '100%';
            statusTip.textContent = "Analysis Complete!";

            if(res.ok) {
                setTimeout(() => {
                    loadingSection.classList.add('hidden');
                    resultsSection.classList.remove('hidden');
                    
                    if(data.batch && data.batch.length > 1) {
                        renderBatchDashboard(data.batch);
                    } else {
                        let singleData = data.batch && data.batch.length === 1 ? data.batch[0] : data;
                        renderDashboard(singleData);
                    }
                }, 500);
            } else {
                alert("Error: " + (data.error || "Failed to process data."));
                resetApp();
            }
        } catch(error) {
            clearInterval(loaderInterval);
            alert("Network Error: Could not reach AI backend.");
            console.error(error);
            resetApp();
        }
    });

    // --- Share Link Logic ---
    document.getElementById('share-link-btn').addEventListener('click', () => {
        const score = document.getElementById('final-score').innerText;
        const mockLink = `https://trustscore.ai/share/profile?id=${Math.random().toString(36).substr(2, 6)}&score=${score}`;
        navigator.clipboard.writeText(mockLink).then(() => {
            alert(`Link copied to clipboard! \n${mockLink}`);
        });
    });

    // --- Render Batch Dashboard ---
    function renderBatchDashboard(batchResults) {
        document.getElementById('batch-results').classList.remove('hidden');
        document.querySelector('.top-grid').classList.add('hidden');
        document.querySelector('.bottom-grid').classList.add('hidden');
        document.querySelector('.factor-grid').classList.add('hidden');
        
        const tbody = document.getElementById('batch-tbody');
        tbody.innerHTML = '';
        
        batchResults.forEach(res => {
            if(res.error) {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td>${res.filename}</td><td colspan="3" style="color:red">Failed: ${res.error}</td>`;
                tbody.appendChild(tr);
                return;
            }
            
            const tr = document.createElement('tr');
            const fileBase = res.filename.split('.')[0].replace('demo_','').toUpperCase();
            
            let highestRisk = res.impacts[res.impacts.length-1]; 
            let riskStr = "None";
            if (highestRisk && highestRisk.impact < 0) {
                 riskStr = `${highestRisk.name} (${highestRisk.impact} pts)`;
            }
            
            let color = '#ef4444'; let pill = 'risk-red';
            if(res.score >= 80) { color = '#10b981'; pill = 'risk-green'; }
            else if(res.score >= 50) { color = '#f59e0b'; pill = 'risk-yellow'; }

            tr.innerHTML = `
                <td><strong>${fileBase}</strong></td>
                <td><span style="font-size:1.4rem; font-weight:700; color:${color}">${res.score}</span> /100</td>
                <td><span class="risk-pill ${pill}">${riskStr}</span></td>
                <td><button class="btn-secondary">View Details</button></td>
            `;
            tbody.appendChild(tr);
        });
    }

    // --- Render Dashboard ---
    function renderDashboard(data) {
        const finalScore = data.score;
        
        animateScoreNumber(finalScore, 2000); 
        renderGaugeChart(finalScore);
        
        const scoreBadge = document.getElementById('score-badge');
        setTimeout(() => {
            if(finalScore >= 80) {
                scoreBadge.textContent = "Excellent Trust Profile";
                scoreBadge.style.backgroundColor = "rgba(16, 185, 129, 0.2)";
                scoreBadge.style.color = "#10b981";
                triggerConfetti();
            } 
            else if(finalScore >= 60) {
                scoreBadge.textContent = "Good Trust Profile";
                scoreBadge.style.backgroundColor = "rgba(59, 130, 246, 0.2)";
                scoreBadge.style.color = "#3b82f6";
            }
            else if(finalScore >= 40) {
                scoreBadge.textContent = "Fair Trust Profile";
                scoreBadge.style.backgroundColor = "rgba(245, 158, 11, 0.2)";
                scoreBadge.style.color = "#f59e0b";
            } else {
                scoreBadge.textContent = "High Risk Profile";
                scoreBadge.style.backgroundColor = "rgba(239, 68, 68, 0.2)";
                scoreBadge.style.color = "#ef4444";
            }
        }, 2000);

        const insightsList = document.getElementById('insights-list');
        insightsList.innerHTML = '';
        data.insights.forEach((insight, idx) => {
            const div = document.createElement('div');
            let cls = 'insight-item ';
            let icon = 'fa-info-circle';
            
            if(insight.toLowerCase().includes('excellent') || insight.toLowerCase().includes('strong') || insight.toLowerCase().includes('healthy')) {
                cls += 'success-insight'; icon = 'fa-check-circle';
            } else if (insight.toLowerCase().includes('missed') || insight.toLowerCase().includes('erratic') || insight.toLowerCase().includes('flag') || insight.toLowerCase().includes('low ')) {
                cls += 'warning-insight'; icon = 'fa-exclamation-triangle';
            }
            
            div.className = cls;
            div.style.animationDelay = `${(idx * 0.1) + 0.3}s`;
            div.innerHTML = `<i class="fas ${icon}"></i> <p>${insight}</p>`;
            insightsList.appendChild(div);
        });

        renderFactorTable(data.raw_features, data.impacts);
        setTimeout(() => renderImpactChart(data.impacts), 300);
    }

    function renderFactorTable(raw, impacts) {
        const tbody = document.getElementById('factor-tbody');
        tbody.innerHTML = '';

        const metrics = [
            { key: 'upi_tx_freq', label: 'UPI Transaction Freq.', format: val => `${val.toFixed(1)} tx/day`, good: val => val > 1, bad: val => val < 0.3 },
            { key: 'bill_payment_delay', label: 'Delayed Bill Ratio', format: val => `${(val * 100).toFixed(1)}%`, good: val => val < 0.1, bad: val => val > 0.3 },
            { key: 'salary_consistency', label: 'Salary Consistency', format: val => `${(val * 100).toFixed(1)}%`, good: val => val > 0.7, bad: val => val < 0.4 },
            { key: 'savings_ratio', label: 'Savings Ratio', format: val => `${(val * 100).toFixed(1)}%`, good: val => val > 0.15, bad: val => val < 0.05 },
            { key: 'expense_volatility', label: 'Expense Volatility', format: val => `${val.toFixed(2)} σ`, good: val => val < 0.5, bad: val => val > 1.2 },
            { key: 'night_risky_spending', label: 'Late Night Tx(s)', format: val => `${parseInt(val)} tx`, good: val => val == 0, bad: val => val > 1 },
            { key: 'rent_payment_discipline', label: 'Rent Discipline', format: val => `${(val * 100).toFixed(1)}%`, good: val => val > 0.8, bad: val => val < 0.5 },
            { key: 'payee_diversity', label: 'Payee Diversity', format: val => `${(val * 100).toFixed(1)}%`, good: val => val > 0.4, bad: val => val < 0.15 }
        ];

        metrics.forEach((m) => {
            const rawVal = raw[m.key] || 0;
            const displayVal = m.format(rawVal);
            
            const mappedImpact = impacts.find(imp => imp.name.toLowerCase().replace(/ /g, '_') === m.key) || { impact: 0 };
            const pts = mappedImpact.impact;
            const ptsDisplay = pts > 0 ? `+${pts.toFixed(1)} pts` : `${pts.toFixed(1)} pts`;
            
            let statusClass = 'risk-yellow';
            let statusIcon = 'fa-minus';
            let statusText = 'Neutral';

            if(m.good(rawVal)) {
                statusClass = 'risk-green';
                statusIcon = 'fa-check';
                statusText = 'Low Risk';
            } else if(m.bad(rawVal)) {
                statusClass = 'risk-red';
                statusIcon = 'fa-times';
                statusText = 'High Risk';
            } else if (pts < 0) {
                statusClass = 'risk-red';
                statusIcon = 'fa-exclamation';
                statusText = 'Elevated Risk';
            } else {
                statusClass = 'risk-green';
                statusIcon = 'fa-check';
                statusText = 'Low Risk';
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><strong>${m.label}</strong></td>
                <td>${displayVal}</td>
                <td>
                    <span class="risk-pill ${statusClass}">
                        <i class="fas ${statusIcon}"></i> ${statusText} [${ptsDisplay}]
                    </span>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    function animateScoreNumber(target, durationMs) {
        let current = 0;
        const dom = document.getElementById('final-score');
        const intervalMs = 20;
        const steps = durationMs / intervalMs;
        const increment = target / steps;

        const interval = setInterval(() => {
            current += increment;
            if(current >= target) {
                current = target;
                clearInterval(interval);
            }
            dom.textContent = Math.round(current);
        }, intervalMs);
    }

    function renderGaugeChart(score) {
        const ctx = document.getElementById('gaugeChart').getContext('2d');
        if(gaugeChartInstance) gaugeChartInstance.destroy();

        let color = '#3b82f6';
        if(score >= 80) color = '#10b981';
        if(score < 40) color = '#ef4444';

        const isLight = document.documentElement.getAttribute('data-theme') === 'light';
        const bg = isLight ? '#e2e8f0' : 'rgba(255,255,255,0.05)';

        gaugeChartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [score, 100 - score],
                    backgroundColor: [color, bg],
                    borderWidth: 0,
                    borderRadius: [10, 0],
                    cutout: '80%',
                    circumference: 260,
                    rotation: 230
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { tooltip: { enabled: false }, legend: { display: false } },
                animation: { animateRotate: true, duration: 2500, easing: 'easeOutQuart' }
            }
        });
    }

    function renderImpactChart(impacts) {
        const ctx = document.getElementById('impactChart').getContext('2d');
        if(impactChartInstance) impactChartInstance.destroy();

        impacts.sort((a,b) => Math.abs(b.impact) - Math.abs(a.impact));

        const labels = impacts.map(i => i.name);
        const data = impacts.map(i => i.impact);
        const isLight = document.documentElement.getAttribute('data-theme') === 'light';
        const textColor = isLight ? '#475569' : '#94a3b8';
        const gridColor = isLight ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';

        const bgColors = data.map(d => d > 0 ? 'rgba(16, 185, 129, 0.8)' : 'rgba(239, 68, 68, 0.8)');

        impactChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Score Adjustment',
                    data: data,
                    backgroundColor: bgColors,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                animation: { duration: 1500, easing: 'easeOutQuart' },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: function(ctx) {
                                let val = ctx.raw;
                                return val > 0 ? `+${val.toFixed(2)} pts` : `${val.toFixed(2)} pts`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { color: gridColor },
                        ticks: { color: textColor, font: { family: 'Outfit' } }
                    },
                    y: {
                        grid: { display: false },
                        ticks: { color: textColor, font: { family: 'Outfit', weight: 500 } }
                    }
                }
            }
        });
    }

    function triggerConfetti() {
        var end = Date.now() + (2.5 * 1000);
        var colors = ['#0ea5e9', '#10b981', '#fcd34d'];

        (function frame() {
            confetti({ particleCount: 8, angle: 60, spread: 55, origin: { x: 0 }, colors: colors });
            confetti({ particleCount: 8, angle: 120, spread: 55, origin: { x: 1 }, colors: colors });
            if (Date.now() < end) requestAnimationFrame(frame);
        }());
    }

    function resetApp() {
        selectedFiles = null;
        fileInput.value = '';
        fileNameDisplay.textContent = '';
        analyzeBtn.disabled = true;
        document.getElementById('score-badge').textContent = "Evaluating";
        
        document.getElementById('batch-results').classList.add('hidden');
        document.querySelector('.top-grid').classList.remove('hidden');
        document.querySelector('.bottom-grid').classList.remove('hidden');
        document.querySelector('.factor-grid').classList.remove('hidden');
        
        resultsSection.classList.add('hidden');
        loadingSection.classList.add('hidden');
        uploadSection.classList.remove('hidden');
        demoSelectorPanel.classList.remove('hidden');
        
        statusTip.textContent = "Scanning UPI & Banking footprint...";
        progressBar.style.width = '0%';
    }
    
    resetBtn.addEventListener('click', resetApp);

    exportPdfBtn.addEventListener('click', () => {
        const element = document.getElementById('report-container');
        const actions = document.querySelector('.results-actions');
        actions.style.display = 'none';
        
        const opt = {
            margin:       0.3,
            filename:     'TrustScore_Report.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true, backgroundColor: document.documentElement.getAttribute('data-theme') === 'light' ? '#ffffff' : '#0f172a' },
            jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(element).save().then(() => {
            actions.style.display = 'flex';
        });
    });
});
